from django.apps import AppConfig


class DvConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'dv'
